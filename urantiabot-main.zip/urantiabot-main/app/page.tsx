"use client";

import React from "react";
import styles from "./page.module.css";

const Home = () => {
  const categories = {
    
    "Start Chat": "function-calling",
    
  };

  return (
    <main className={styles.main}>
      <div className={styles.pchead}>        
      <a href="https://prismcortex.net" target="_blank" rel="noopener noreferrer">
        <img src="https://s3.amazonaws.com/prismcortex.net/logos/PCLogoSupportblk.png" alt="Prism Cortex Logo" />
      </a>
    </div>
      <div className={styles.title}>
      
      Explore the wonders of the Urantia Book.<br>
      </br>Chat with your Thought Adjuster now.
      </div>
      
      <div className={styles.container}>
        {Object.entries(categories).map(([name, url]) => (
          <a key={name} className={styles.category} href={`/examples/${url}`}>
            {name}
          </a>
        ))}
      </div>
    </main>
  );
};

export default Home;
